import React, { useState } from 'react';

const AtendimentoPasswordGenerator = () => {
  const [highPriorityCount, setHighPriorityCount] = useState(1);
  const [mediumPriorityCount, setMediumPriorityCount] = useState(1);
  const [lowPriorityCount, setLowPriorityCount] = useState(1);
  const [generatedPassword, setGeneratedPassword] = useState('');

  const generateHighPriorityPassword = () => {
    const newPassword = `AP${String(highPriorityCount).padStart(2, '0')}`;
    setGeneratedPassword(newPassword);
    setHighPriorityCount(highPriorityCount + 1);
  };

  const generateMediumPriorityPassword = () => {
    const newPassword = `P${String(mediumPriorityCount).padStart(2, '0')}`;
    setGeneratedPassword(newPassword);
    setMediumPriorityCount(mediumPriorityCount + 1);
  };

  const generateLowPriorityPassword = () => {
    const newPassword = `N${String(lowPriorityCount).padStart(2, '0')}`;
    setGeneratedPassword(newPassword);
    setLowPriorityCount(lowPriorityCount + 1);
  };

  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h2>Gerador de Senhas de Atendimento</h2>
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '20px' }}>
        <button
          onClick={generateHighPriorityPassword}
          style={{
            backgroundColor: 'blue',
            color: 'white',
            width: '150px',
            height: '150px',
            fontSize: '16px',
            margin: '10px',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
          }}
        >
          Alta Prioridade
        </button>
        <button
          onClick={generateMediumPriorityPassword}
          style={{
            backgroundColor: 'yellow',
            color: 'black',
            width: '150px',
            height: '150px',
            fontSize: '16px',
            margin: '10px',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
          }}
        >
          Média Prioridade
        </button>
        <button
          onClick={generateLowPriorityPassword}
          style={{
            backgroundColor: 'green',
            color: 'white',
            width: '150px',
            height: '150px',
            fontSize: '16px',
            margin: '10px',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
          }}
        >
          Baixa Prioridade
        </button>
      </div>
      <h3 style={{ marginTop: '20px' }}>Senha Gerada:</h3>
      <p style={{ fontWeight: 'bold' }}>{generatedPassword}</p>
    </div>
  );
};

export default AtendimentoPasswordGenerator;